// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

import { createHashHistory } from "history";
export default createHashHistory();
